import datetime


def seconds_to_time(seconds):
    return datetime.datetime.fromtimestamp(seconds)


import os

print("created", seconds_to_time(os.path.getctime("personenliste.py")))
print("modified", seconds_to_time(os.path.getmtime("personenliste.txt")))
print("accessed", seconds_to_time(os.path.getatime("personenliste.txt")))
