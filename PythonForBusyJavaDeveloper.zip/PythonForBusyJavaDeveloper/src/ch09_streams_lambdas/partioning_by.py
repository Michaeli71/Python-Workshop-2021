import itertools

words = ["Salami", "Obstkorb", "Käsekuchen", "Obstkuchen", "Obstsalat"]

result = {}
extract_category = lambda entry: entry.startswith("Obst")
for key, group in itertools.groupby(words, extract_category):
    members = result.get(key, []) + \
              list([entry for entry in group])
    result.update({key: members})

print(result)

########### Methode extrahieren

values = ["Salami", "Obstkorb", "Käsekuchen", "Obstkuchen", "Obstsalat"]
criterion = lambda entry: entry.endswith("kuchen")


# praktisch
def partioning_by(values, criterion):
    result = {}
    for key, group in itertools.groupby(values, criterion):
        members = result.get(key, []) + \
                  list([entry for entry in group])
        result.update({key: members})
    return result


result = partioning_by(values, criterion)
print(result)

result = partioning_by(values, extract_category)
print(result)
