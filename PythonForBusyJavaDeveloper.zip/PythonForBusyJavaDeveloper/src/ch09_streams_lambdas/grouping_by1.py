things = [("animal", "Bear"), ("sport", "Golf"), ("sport", "Karate"),
          ("sport", "Bowling"), ("vehicle", "Bicycle"), ("animal", "Dog"),
          ("vehicle", "Car"), ("animal", "Tiger")]

import itertools

for key, group in itertools.groupby(things, lambda entry: entry[0]):
    for entry in group:
        print("%s is a %s. (Key: %s)" % (entry[1], entry[0], key))
        print("")
