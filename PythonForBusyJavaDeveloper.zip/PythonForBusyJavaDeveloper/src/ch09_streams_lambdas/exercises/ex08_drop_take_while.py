data = ["x", "y", "<START>", "FIRST", "SECOND", "<END>", "x", "y"]

# TODO
