values = ["a", "cc", "bbb", "dddd", "ee", "f"]
new_list = sorted(values, key=lambda x: (len(x), x))
print(values)


programmers = [("Tim", ["Java"]), ("Tom", ["Java", "Python"]),
               ("Michael", ["Java", "Python"]), ("Jim", ["Python"]),
               ("Polyglotti", ["Java", "Python", "C#", "C++"])]

print(sorted(programmers, key=lambda x: (-len(x[1]), x[0])))
