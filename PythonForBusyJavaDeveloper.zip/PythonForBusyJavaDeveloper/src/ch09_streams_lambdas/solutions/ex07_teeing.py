import itertools

conferences = ["Devoxx", "Voxxed Days", "Oracle Code One", "Basel One", "JAX", "W-JAX",
               "JAX London"]

# aufspalten in n Iteratoren
it1, it2 = itertools.tee(conferences, 2)

xx = filter(lambda str: "xx" in str, it1)
ones = filter(lambda str: str.endswith("One"), it2)

print((list(xx), list(ones)))

#############################################
# mit Python einfach mit Java???

it1, it2, it3 = itertools.tee(conferences, 3)

xx = filter(lambda str: "xx" in str, it1)
ones = filter(lambda str: str.endswith("One"), it2)
jax = filter(lambda str: "JAX" in str, it3)

print((list(xx), list(ones), list(jax)))