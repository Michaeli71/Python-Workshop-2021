import itertools

numbers = [1, 2, 3, 4, 5, 6, 7]

# aufspalten in n Iteratoren
it1, it2 = itertools.tee(numbers, 2)

sum_ = sum(it1)
count_ = sum(1 for _ in it2)

print((sum_, count_))

