

min_ = min([2, 3, 41])
print(min_)

# print(min([1, 2, 3]))
