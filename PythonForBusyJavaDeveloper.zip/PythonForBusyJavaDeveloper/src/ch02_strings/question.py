text = list("ABCDEFGHIJKLMNOP")

idx = 7
print(text[4:idx])
text[4:idx] = []
print(text)
