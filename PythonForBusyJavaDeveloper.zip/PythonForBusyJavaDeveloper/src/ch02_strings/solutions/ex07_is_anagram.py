def is_anagram(str1, str2):
    char_counts1 = calc_char_frequencies(str1)
    char_counts2 = calc_char_frequencies(str2)

    return char_counts1 == char_counts2


def calc_char_frequencies(input):
    char_counts = {}
    for current_char in input.upper():
        if current_char in char_counts:
            char_counts[current_char] += 1
        else:
            char_counts[current_char] = 1
    return char_counts


print(is_anagram("Ampel", "Lampe"))
print(is_anagram("Ampel", "Palme"))
print(is_anagram("Palme", "Lampe"))