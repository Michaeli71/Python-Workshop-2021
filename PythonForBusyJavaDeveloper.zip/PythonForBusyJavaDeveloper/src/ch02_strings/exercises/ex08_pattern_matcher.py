def matches_pattern(pattern, input):
    # TODO
    pass


print(matches_pattern("xyyx", "tim mike mike tim"))
print(matches_pattern("xyyx", "tim mike tom tim"))
