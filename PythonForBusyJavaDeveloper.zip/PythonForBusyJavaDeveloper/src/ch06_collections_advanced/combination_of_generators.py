def fac_generator(n):
    iteration = 1
    result = 1
    while iteration <= n:
        yield result
        iteration += 1
        result *= iteration


def square(nums):
    for num in nums:
        yield num ** 2


def double(nums):
    for num in nums:
        yield num * 2


for i in double(fac_generator(5)):
    print(i)
