def fibonacci_numbers(nums):
    # TODO
    pass


def square(nums):
    # TODO
    pass


values = list(fibonacci_numbers(10))
print(values)
print(sum(values))

fibsquared = square(fibonacci_numbers(10))
print(next(fibsquared))
print(next(fibsquared))
print(next(fibsquared))
print(next(fibsquared))


values = list(square(fibonacci_numbers(10)))
print(values)
print(sum(values))
