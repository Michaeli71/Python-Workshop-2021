it = iter([2, 4, 6, 8, 10])
print(next(it))
print(next(it))


iter_obj = iter([2, 4, 6, 8, 10])

# Endlosschleife
while True:
    try:
        # Zugriff auf nächstes Element
        element = next(iter_obj)
        # do something with element
        print(element)
    except StopIteration:
        # Abbruch im Falle einer StopIteration
        break
