def fibonacci_numbers(nums):
    x, y = 0, 1
    for _ in range(nums):
        x, y = y, x + y
        yield x


def square(nums):
    for num in nums:
        yield num ** 2


values = list(fibonacci_numbers(10))
print(values)
print(sum(values))

fibsquared = square(fibonacci_numbers(10))
print(next(fibsquared))
print(next(fibsquared))
print(next(fibsquared))
print(next(fibsquared))


values = list(square(fibonacci_numbers(10)))
print(values)
print(sum(values))
