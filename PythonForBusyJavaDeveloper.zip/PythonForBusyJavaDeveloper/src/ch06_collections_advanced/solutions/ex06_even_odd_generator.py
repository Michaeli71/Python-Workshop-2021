def all_even():
    n = 0
    while True:
        yield n
        n += 2


def all_odd():
    n = 1
    while True:
        yield n
        n += 2


