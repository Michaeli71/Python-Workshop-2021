class FibonacciIterator:
    def __init__(self, n=0):
        self.n = n
        self.values = [0, 1]
        self.iteration = 0

    def __iter__(self):
        return self

    def __next__(self):
        if self.iteration >= self.n:
            raise StopIteration

        self.iteration += 1
        if self.iteration < 2:
            return self.values[self.iteration - 1]

        self.values.append(self.values[-2] + self.values[-1])
        return self.values[self.iteration - 1]


for i in FibonacciIterator(10):
    print(i)

