names = ["tim", "TOM", "MIKE", "Michael", "andreas", "STEFAN"]

names.sort(key=str.lower)
print(names)

names.sort(key=str.casefold)
print(names)


