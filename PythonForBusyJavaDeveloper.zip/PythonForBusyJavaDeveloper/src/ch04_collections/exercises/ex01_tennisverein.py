mitglieder_liste = []

# TODO

print(len(mitglieder_liste))
