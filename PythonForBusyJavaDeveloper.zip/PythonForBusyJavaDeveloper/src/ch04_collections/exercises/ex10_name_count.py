names = ["Tim", "Tom", "Mike", "Jim", "Tim", "Mike", "James", "Mike"]

# TODO


