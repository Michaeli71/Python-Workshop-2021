def number_as_text(n):
    # TODO
    pass


print(number_as_text(721971))
