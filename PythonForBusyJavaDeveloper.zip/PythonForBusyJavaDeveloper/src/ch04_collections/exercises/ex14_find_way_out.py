def find_way_out(values, x, y):
    # TODO

    raise ValueError("wrong char in labyrinth")


def print_array(values2dim):
    max_y, max_x = get_dimension(values2dim)
    for y in range(max_y):
        for x in range(max_x):
            value = values2dim[y][x]
            print(str(value), end='')

        print()


def get_dimension(values):
    if isinstance(values, list):
        return len(values), len(values[0])

    raise ValueError("unsupported type", type(values))


def main():
    world_big = [list("##################################"),
                 list("# #         #    #     #  #   X#X#"),
                 list("#  ##### #### ##   ##  #  # ###  #"),
                 list("#  ##  #    #  ## ##  #  #     # #"),
                 list("#    #  ###  # ## ##   #   ### # #"),
                 list("# #   ####     ## ##      ###  # #"),
                 list("####   #     ####  ####  # ####  #"),
                 list("######   #########   ##   # ###  #"),
                 list("##     #  X X####X #  #  # ###  ##"),
                 list("##################################")]

    print_array(world_big)
    if find_way_out(world_big, 1, 1):
        print_array(world_big)


if __name__ == "__main__":
    main()
