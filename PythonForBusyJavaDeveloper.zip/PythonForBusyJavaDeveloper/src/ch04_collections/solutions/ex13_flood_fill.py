from enum import Enum


def flood_fill(values2dim, x, y):
    max_y, max_x = get_dimension(values2dim)
    # rekursiver Abbruch
    if x < 0 or y < 0 or x >= max_x or y >= max_y:
        return

    if values2dim[y][x] == ' ':
        values2dim[y][x] = '*'

        # rekursiver Abstieg: fülle in alle 4 Richtungen
        flood_fill(values2dim, x, y - 1)
        flood_fill(values2dim, x + 1, y)
        flood_fill(values2dim, x, y + 1)
        flood_fill(values2dim, x - 1, y)


def flood_fill_with_pattern(values2dim, x, y, pattern):
    max_y, max_x = get_dimension(values2dim)

    # rekursiver Abbruch
    if x < 0 or y < 0 or x >= max_x or y >= max_y:
        return

    if values2dim[y][x] == ' ':
        values2dim[y][x] = find_fill_char(y, x, pattern)

        # fill in all 4  dirs
        for dir in Direction:
            dy, dx = dir.value

            flood_fill_with_pattern(values2dim, x + dx, y + dy, pattern)


def find_fill_char(y, x, pattern):
    max_y, max_x = get_dimension(pattern)
    return pattern[y % max_y][x % max_x]


class Direction(Enum):
    UP = (-1, 0)
    DOWN = (1, 0)
    LEFT = (0, -1)
    RIGHT = (0, 1)


def generate_pattern():
    return [list("---"), list("~~~"), list("===")]


def get_dimension(values):
    if isinstance(values, list):
        return len(values), len(values[0])

    raise ValueError("unsupported type", type(values))


def print_array(values2dim):
    max_y, max_x = get_dimension(values2dim)
    for y in range(max_y):
        for x in range(max_x):
            value = values2dim[y][x]
            print(str(value), end='')

        print()


def generate_big_world():
    return [list("           #   |     "),
            list("       ##   #   |    "),
            list("    #####    #   __  "),
            list("       ###   #     | "),
            list(" ###    #    #      |"),
            list("    #   #    #     | "),
            list("     # #    #    --  "),
            list("      #    #    |    ")]


def main():
    world = [
        [" ", " ", "x", " ", " ", " "],
        [" ", " ", " ", "#", " ", " "],
        ["#", " ", " ", "#", " ", " "],
        [" ", "#", " ", "#", " ", " "],
        [" ", " ", "#", " ", " ", " "]
    ]

    print_array(world)
    flood_fill(world, 2, 2)
    print_array(world)

    world1 = [
        [" ", " ", "x", " ", " ", " "],
        [" ", " ", " ", "#", " ", " "],
        ["#", " ", " ", "#", " ", " "],
        [" ", "#", " ", "#", " ", " "],
        [" ", " ", "#", " ", " ", " "]
    ]

    print_array(world1)
    flood_fill(world1, 5, 4)
    print_array(world1)

    world2 = generate_big_world()
    print_array(world2)
    flood_fill(world2, 5, 4)
    print_array(world2)

    world3 = generate_big_world()
    print_array(world3)
    flood_fill_with_pattern(world3, 5, 4, generate_pattern())
    print_array(world3)


if __name__ == "__main__":
    main()
