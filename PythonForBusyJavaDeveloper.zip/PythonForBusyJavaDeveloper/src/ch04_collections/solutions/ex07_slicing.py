numbers = [3,4,5,6,7,8,9]

numbers[:0] = [1, 2]
print(numbers)
numbers[len(numbers):] = [10, 11]
print(numbers)

numbers[4:7] = []
print(numbers)

numbers[1:-1] = []
print(numbers)
