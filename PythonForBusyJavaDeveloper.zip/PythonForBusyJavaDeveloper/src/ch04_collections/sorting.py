names = ["Mike", "Andy", "Peter", "Jim", "Tim"]
names.sort()
print(names)

names.sort(reverse=True)
print(names)

names.sort(key=lambda name: name[2])
print(names)

names.sort(key=lambda name: name[-1])
print(names)
