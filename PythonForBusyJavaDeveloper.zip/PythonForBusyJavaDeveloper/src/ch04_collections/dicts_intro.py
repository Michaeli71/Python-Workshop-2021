city_inhabitants_map = {}

city_inhabitants_map["Zürich"] = 400_000
city_inhabitants_map["Hamburg"] = 2_000_000
city_inhabitants_map["Kiel"] = 250_000

print(city_inhabitants_map)

city_inhabitants_map.update({ "Bern" : 170_000, "Berlin" : 3_500_000 })
print(city_inhabitants_map)

for key, value in city_inhabitants_map.items():
    print("The city of", key, "has", value, "inhabitants")

print("-".join(city_inhabitants_map.keys()))
print("Gesamteinwohner:", sum(city_inhabitants_map.values()))

print("Zürich" in city_inhabitants_map)
print("Bremen" in city_inhabitants_map)

print(400_000 in city_inhabitants_map.values())
print(1_234_567 in city_inhabitants_map.values())


city_inhabitants_map["Bern"] = 180_000

del city_inhabitants_map["Bern"]
print(city_inhabitants_map)

city_inhabitants_map.pop("Kiel")
print(city_inhabitants_map)

city_inhabitants_map.clear()
print(len(city_inhabitants_map))


