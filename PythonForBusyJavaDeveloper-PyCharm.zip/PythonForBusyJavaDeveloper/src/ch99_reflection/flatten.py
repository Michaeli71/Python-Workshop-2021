from collections.abc import Iterable


def flatten(values):
    result = []

    for val in values:
        if isiterable(val):
            # WICHTIG
            if isinstance(val, str):
                result.append(val)
            else:
                result += flatten(val)
        else:
            result.append(val)
    return result


def isiterable(obj):
    return isinstance(obj, Iterable)


# Alternative
def isiterable(obj):
    try:
        iter(obj)
    except Exception:
        return False
    else:
        return True



print(flatten([1, [2, 3], [4, [5, 6, 7, 8], 9], 0]))

# Problem ohne str check
print(flatten([1, [2, 3], [4, [5, "ABC", (2,3), 7, 8], 9], 0]))
