# pip install requests

import requests


def print_response_info(address):
    response = requests.get(address)
    print(response)
    print(response.status_code)
    print(response.headers)
    print(response.text)

    with open("../ch99_web_http/python.html", "w") as html_file:
        html_file.write(response.text)


print_response_info('https://reqres.in/api/users?page=2')
print_response_info("https://www.python.org/")

