def to_morse_code(input):
    # TODO
    pass


# TODO


print(to_morse_code("SOS"))
print(to_morse_code("TWEET"))
