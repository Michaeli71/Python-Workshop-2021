def last_index_of(values, search_for):
    # TODO

    return -1


def rindex(values, search_for):
    # TODO

    return -1


# Alternative
def rindex(values, search_for):
    # TODO

    return -1


def rfind(values, search_for):
    # TODO

    raise ValueError(str(search_for) + " not found")


print(last_index_of([1, 2, 3, 2, 4, 2, 5, 2], 2))  # => 7
print(last_index_of([1, 2, 3, 2, 4, 2, 5, 2], 7))  # => -1


######################################

def last_index_of(values, search_for, startpos = None):
    # TODO

    return -1


def rfind(values, search_for, startpos = None):
    # TODO

    raise ValueError(str(search_for) + " not found")


print(last_index_of([1, 2, 3, 2, 4, 2, 5, 2], 2, 6))  # => 5
print(last_index_of([1, 2, 3, 2, 4, 2, 5, 2], 2, 4))  # => 3
