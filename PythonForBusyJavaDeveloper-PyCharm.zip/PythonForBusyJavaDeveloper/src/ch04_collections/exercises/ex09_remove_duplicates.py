def remove_duplicates(inputs):
    result = []
    # TODO

    return result


print(remove_duplicates([7,2,7,1]))
print(remove_duplicates([1,6,6,6,1,2]))
