def find_way_out(values, x, y):
    if x < 0 or y < 0 or x > len(values[0]) or y >= len(values):
        return False

    # rekursiver Abbruch
    if values[y][x] == 'X':
        print("FOUND EXIT: x: {}, y: {}".format(x, y))
        return True

    # Mauer oder bereits besucht?
    if values[y][x] in '#.':
        return False

    # rekursiver Abstieg
    if values[y][x] == ' ':
        #   markiere als besucht
        values[y][x] = '.'

        # versuche alle 4 Himmelsrichtungen
        up = find_way_out(values, x, y - 1)
        left = find_way_out(values, x + 1, y)
        down = find_way_out(values, x, y + 1)
        right = find_way_out(values, x - 1, y)

        found_a_way = up or left or down or right

        # Backtracking, weil keine gültige Lösung
        if not found_a_way:
            # falscher Weg, somit Feldmarkierung löschen
            values[y][x] = ' '

        return found_a_way

    raise ValueError("wrong char in labyrinth")


def print_array(values2dim):
    max_y, max_x = get_dimension(values2dim)
    for y in range(max_y):
        for x in range(max_x):
            value = values2dim[y][x]
            print(str(value), end='')

        print()


def get_dimension(values):
    if isinstance(values, list):
        return len(values), len(values[0])

    raise ValueError("unsupported type", type(values))


def main():
    world_big = [list("##################################"),
                 list("# #         #    #     #  #   X#X#"),
                 list("#  ##### #### ##   ##  #  # ###  #"),
                 list("#  ##  #    #  ## ##  #  #     # #"),
                 list("#    #  ###  # ## ##   #   ### # #"),
                 list("# #   ####     ## ##      ###  # #"),
                 list("####   #     ####  ####  # ####  #"),
                 list("######   #########   ##   # ###  #"),
                 list("##     #  X X####X #  #  # ###  ##"),
                 list("##################################")]

    print_array(world_big)
    if find_way_out(world_big, 1, 1):
        print_array(world_big)


if __name__ == "__main__":
    main()
