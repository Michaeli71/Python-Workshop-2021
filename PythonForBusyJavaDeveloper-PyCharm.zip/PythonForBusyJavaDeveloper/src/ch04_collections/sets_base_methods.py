numbers = {11, 2, 3, 4, 5, 6, 7, 8, 9}

print("len:", len(numbers))
print("min:", min(numbers))
print("max:", max(numbers))
print("sum:", sum(numbers))


names = set()

names.add("Tim")
names.add("Tom")
print(names)

names.add("Tim")
names.add("Last")
print(names)

names.update(["Mike", "Peter", "John"])
print(names)

names.update("Michael")
print(names)

###########################################

for letter in "Michael":
    names.remove(letter)
print(names)

names.remove("Tom")
names.remove("Last")
print(names)
names.clear()
print(names)

#names.remove("Tim")


#######################################################

number_set1 = {1, 2, 3, 4, 5, 6, 7, 8}
number_set2 = {2, 3, 5, 7, 9, 11, 13}
print("union: %s\nintersection: %s" \
      "\ndiff 1-2: %s\ndiff 2-1: %s" \
      "\nsym diff: %s" %
       ((number_set1 | number_set2), (number_set1 & number_set2),
        (number_set1 - number_set2), (number_set2 - number_set1),
        (number_set1 ^ number_set2)))


issubset = {"ABC", 42.195} & {0, "ABC", 42.195, True} == {"ABC", 42.195}
print(issubset)

print({"ABC", 42.195}.issubset({0, "ABC", 42.195, True}))
print({0, "ABC", 42.195, True}.issuperset({"ABC", 42.195}))
