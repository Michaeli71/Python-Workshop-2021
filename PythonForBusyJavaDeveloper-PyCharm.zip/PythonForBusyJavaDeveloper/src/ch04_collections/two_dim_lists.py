twodim_triangle = [[1],
                   [2, 2],
                   [3, 3, 3]]
