from ch04_collections.stack import Stack


def reverse_order(values):
    stack = Stack()

    for val in values:
        stack.push(val)

    result = []
    while not stack.is_empty():
        result.append(stack.pop())

    return result

def main():
    values = ["AB", "BC", "CD", "DE"]
    print(reverse_order(values))


if __name__ == "__main__":
    main()
