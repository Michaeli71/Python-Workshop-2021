

squares = [value * value for value in range(10) if value % 2 == 0]

def even_double_odd_next_even(n):
    if n % 2 == 0:
        return n * 2
    else:
        return n + 1

result = [even_double_odd_next_even(value) for value in range(10)]
print(result)


def even_triple_odd_next_even(n):
    if n % 2 == 0:
        return n * 3
    else:
        return n + 1

result = [even_triple_odd_next_even(value) for value in range(10)]
print(result)


def special(n):
    if n % 2 == 0:
        return n * 2 + 1
    else:
        return n * 2 - 1

result = [special(value) for value in range(10)]
print(result)



endings = ["st", "nd", "rd"] + 17 * ["th"] + \
          ["st", "nd", "rd"] + 7 * ["th"] + \
          ["st"]

for i in range(1, 32):
    print(str(i) + endings[i-1])

