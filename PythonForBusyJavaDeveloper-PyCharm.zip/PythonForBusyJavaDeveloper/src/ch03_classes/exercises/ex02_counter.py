class Counter:
    def __init__(self, count):
        self.count = count
