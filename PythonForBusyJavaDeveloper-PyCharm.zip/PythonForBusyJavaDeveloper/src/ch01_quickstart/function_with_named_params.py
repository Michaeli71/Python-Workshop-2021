def parameter_example(first, second):
    print("first:", first)
    print("second:", second)


parameter_example(1, 22)
parameter_example(second = 22, first = 1)