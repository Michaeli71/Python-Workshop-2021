import min_operations


def main():
    print(min_operations.min_of_3(72, 71, 42))


if __name__ == "__main__":
    main()