def count_leap_years(start, end):
    # TODO
    pass


print(count_leap_years(2010, 2019))
print(count_leap_years(2000, 2019))


def count_leap_years_2(start, end):
    # TODO
    pass


print(count_leap_years_2(2010, 2019))
print(count_leap_years_2(2000, 2019))
