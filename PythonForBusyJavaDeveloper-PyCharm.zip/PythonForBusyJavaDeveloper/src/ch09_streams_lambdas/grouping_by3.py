import itertools

values = ["Tim", "Tom", "Micha", "John", "Tim"]

# group by first char
key_extractor = lambda entry: entry[0]
sorted_by_first_char = sorted(values, key=key_extractor)
print(sorted_by_first_char)

# GROUPING BY
result = {}
for key, group in itertools.groupby(sorted_by_first_char, key_extractor):
    result[key] = list(group)
print(result)


# => grouping by

# praktisch
def grouping_by(values, key_extractor):
    result = {}
    sorted_by_key = sorted(values, key=key_extractor)
    for key, group in itertools.groupby(sorted_by_key, key_extractor):
        result[key] = list(group)
    return result


print(grouping_by(values, key_extractor))
