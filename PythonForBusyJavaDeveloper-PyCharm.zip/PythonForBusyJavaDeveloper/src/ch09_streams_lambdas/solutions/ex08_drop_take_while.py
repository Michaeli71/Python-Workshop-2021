import itertools

data = ["x", "y", "<START>", "FIRST", "SECOND", "<END>", "x", "y"]

payload_start = itertools.dropwhile(lambda str: str != "<START>", data)
real_paylod = list(itertools.takewhile(lambda str: str != "<END>", payload_start))[1:]
print(real_paylod)

# kürzer
real_paylod = list(itertools.takewhile(lambda str: str != "<END>",
                                       itertools.dropwhile(lambda str: str != "<START>", data)))[1:]
print(real_paylod)