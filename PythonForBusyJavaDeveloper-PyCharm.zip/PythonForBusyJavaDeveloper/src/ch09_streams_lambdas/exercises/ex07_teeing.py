conferences = ["Devoxx", "Voxxed Days", "Oracle Code One", "Basel One", "JAX", "W-JAX",
               "JAX London"]

# TODO
xx = [] # TODO
ones = [] # TODO

print((list(xx), list(ones)))
