def all_even():
    n = 0
    while True:
        yield n
        n += 2


gen = all_even()
print(next(gen))
print(next(gen))
print(next(gen))
print(next(gen))
