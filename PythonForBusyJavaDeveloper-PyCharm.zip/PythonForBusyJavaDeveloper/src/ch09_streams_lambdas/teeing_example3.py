import itertools

names = ["Michael", "Tim", "Tom", "Mike", "Bernd"]

it1, it2 = itertools.tee(names, 2)

starts_with_mi = list(filter(lambda text: text.startswith("Mi"), it1))
ends_with_m = [text for text in it2 if text.endswith("m")]

print([starts_with_mi, ends_with_m])

