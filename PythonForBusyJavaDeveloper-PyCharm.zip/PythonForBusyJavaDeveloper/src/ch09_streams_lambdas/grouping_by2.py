import itertools

values = [("Tim", 49), ("Tom", 7), ("Micha", 50), ("John", 7), ("Tim", 50)]

# group by age
key_extractor = lambda entry: entry[1]
sorted_by_age = sorted(values, key=key_extractor)
print(sorted_by_age)

# GROUPING BY
result = {}
for key, group in itertools.groupby(sorted_by_age, key_extractor):
    result[key] = list(group)
print(result)

# ADVANCED nur auf Wert beschränkt
result = {}
for key, group in itertools.groupby(sorted_by_age, key_extractor):
    members = result.get(key, []) + \
              list([entry[0] for entry in group])
    result.update({key: members})

print(result)
