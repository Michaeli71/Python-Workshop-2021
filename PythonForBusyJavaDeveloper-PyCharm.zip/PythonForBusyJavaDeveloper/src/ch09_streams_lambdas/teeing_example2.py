import itertools

numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]

# aufspalten in n Iteratoren
it1, it2, it3 = itertools.tee(numbers, 3)

odd_numbers = list(filter(lambda n: n % 2 != 0, it1))
# odd_numbers_nicer = [n for n in it1 if n % 2 != 0]
sum_ = sum(it2)
count_ = sum(1 for _ in it3)

print((odd_numbers, sum_ / count_))


