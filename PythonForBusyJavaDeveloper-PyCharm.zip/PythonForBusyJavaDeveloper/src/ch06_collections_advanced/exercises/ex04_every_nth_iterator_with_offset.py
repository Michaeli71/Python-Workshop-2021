class EveryNthWithOffset:
    def __init__(self, values, step, offset = 0):
        self.values = values
        self.pos = offset
        self.step = step

    # TODO


second_list = EveryNthWithOffset([1,2,3,4,5,6,7,8,9,10], 3)
print(list(second_list))

second_list = EveryNthWithOffset([1,2,3,4,5,6,7,8,9,10], 3, 2)
print(list(second_list))

