def all_even():
    # TODO
    pass

def all_odd():
    # TODO
    pass


