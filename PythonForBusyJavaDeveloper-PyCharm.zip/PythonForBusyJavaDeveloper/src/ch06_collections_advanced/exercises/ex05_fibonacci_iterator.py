class FibonacciIterator:
    def __init__(self, n=0):
        self.n = n
        self.values = [0, 1]
        self.iteration = 0

    # TODO


for i in FibonacciIterator(10):
    print(i)

