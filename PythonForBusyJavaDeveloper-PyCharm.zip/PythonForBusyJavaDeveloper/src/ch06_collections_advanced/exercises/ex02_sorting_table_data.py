# "Werte einer Tabelle"
values = [["Micha", 50, 8047, "Zürich"],
          ["Lili", 42, 8047, "Zürich"],
          ["Tim", 50, 24107, "Kiel"],
          ["Andreas", 50, 21012, "Hamburg"],
          ["Barbara", 48, 22395, "Hamburg"],
          ["Marianne", 83, 28816, "Stuhr"]]

# Sortieurng nach Name
# TODO

# Sortieurng nach PLZ
# TODO

# Sortieurng nach Alter absteigend => aber was ist bei gleichem Alter?!
# TODO

# Nach Stadt, absteigend PLZ
# TODO

# Nach Stadt, absteigend PLZ, Name
# TODO
