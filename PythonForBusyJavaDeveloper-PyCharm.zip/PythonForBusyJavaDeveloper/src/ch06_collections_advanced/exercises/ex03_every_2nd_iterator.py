class Every2nd:
    def __init__(self, values):
        self.values = values
        self.pos = 0

    # TODO


second_list = Every2nd([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
print(list(second_list))
