values = [[5, 1, 2],
          [1, 3, 5],
          [2, 5, 1],
          [3, 2, 3],
          [4, 4, 4]]

for i in range(3):
    values.sort(key=lambda x: x[i])
    print(values)
