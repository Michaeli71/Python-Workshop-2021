# "Werte einer Tabelle"
values = [["Micha", 50, 8047, "Zürich"],
          ["Lili", 42, 8047, "Zürich"],
          ["Tim", 50, 24107, "Kiel"],
          ["Andreas", 50, 21012, "Hamburg"],
          ["Barbara", 48, 22395, "Hamburg"],
          ["Marianne", 83, 28816, "Stuhr"]]

# Sortieurng nach Name
values.sort(key=lambda x: x[0])
print(values)

# Sortieurng nach PLZ
values.sort(key=lambda x: x[2])
print(values)

# Sortieurng nach Alter absteigend => aber was ist bei gleichem Alter?!
values.sort(key=lambda x: x[1], reverse=True)
print(values)

# HMM ... Tupel gut, aber jetzt ist die Reihenfolge in den Namen nicht wie gewünscht
values.sort(key=lambda x: (x[1], x[0]), reverse=True)
print(values)

# So geht es dann, aber nur möglich, wenn die "Spalte" ein Zahlenwert it
values.sort(key=lambda x: (-x[1], x[0]))
print(values)

# Nach Stadt, absteigend PLZ
values.sort(key=lambda x: (x[3], -x[2]))
print(values)

# Nach Stadt, absteigend PLZ, Name
values.sort(key=lambda x: (x[3], -x[2], x[0]))
print(values)
