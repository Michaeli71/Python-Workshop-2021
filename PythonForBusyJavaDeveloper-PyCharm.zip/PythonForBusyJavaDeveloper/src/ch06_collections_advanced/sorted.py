values = ["a", "cc", "bbb", "dddd", "ee", "f", "d", "eee"]
print(sorted(values, key=lambda x: (len(x), x)))

############################################

values = ["a", "cc", "bbb", "dddd", "ee", "f", "d", "eee"]
print(sorted(values, key=lambda x: (-len(x), x)))

values = ["a", "cc", "bbb", "dddd", "ee", "f", "d", "eee"]
print(sorted(values, key=lambda x: (len(x), x), reverse=True))
