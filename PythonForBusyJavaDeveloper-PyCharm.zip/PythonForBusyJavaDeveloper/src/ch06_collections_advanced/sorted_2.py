from collections import namedtuple

Person = namedtuple('Person', ['name', 'age'])

persons = [Person("Mike", 30), Person("Tim", 50),
           Person("Michael", 50), Person("Tom", 30),
           Person("Arne", 7), Person("Jim", 30)]

# Alter absteigend
persons.sort(key=lambda p: p.age, reverse=True)
print(persons)

persons.sort(key=lambda p: -p.age)
print(persons)

# Name absteigend
persons.sort(key=lambda p: p.name, reverse=True)
print(persons)

# persons.sort(key=lambda p: -p.name)
# print(persons)

# Name, Alter absteigend
persons.sort(key=lambda p: (p.name, -p.age))
print(persons)

# Alter, Name
persons.sort(key=lambda p: (p.age, p.name))
print(persons)

# Alter, Name absteigend
persons.sort(key=lambda p: (-p.age, p.name), reverse=True)
print(persons)
