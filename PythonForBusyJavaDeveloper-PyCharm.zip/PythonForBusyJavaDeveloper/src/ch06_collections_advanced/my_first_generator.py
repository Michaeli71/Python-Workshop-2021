def my_first_generator():
    n = 1
    print('before first')
    yield n
    n *= 2
    print('before second')
    yield n
    n *= 3
    print('before third and last')
    yield n


gen = my_first_generator()
print(next(gen))
print(next(gen))
print(next(gen))
